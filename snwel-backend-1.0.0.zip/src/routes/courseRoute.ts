import express from 'express';
import AuthRouter from './authRoute';
import { getUserListController } from '@/controllers/userController';
import passport from 'passport';
import { getAllCoursesController } from '@/controllers/courseController';

const router = express.Router();

router.get('/', passport.authenticate('jwt', {session: false}), getAllCoursesController);



export { router as CourseRouter };
