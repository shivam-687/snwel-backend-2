import express from 'express';
import { helloController } from '../controllers/helloController';
import { authenticateJWT } from '../middleware/auth.middleware';
import AuthRouter from './authRoute';
import { UserRouter } from './userRoute';
import { CourseRouter } from './courseRoute';

const router = express.Router();

router.get('/', helloController)
router.use('/auth', AuthRouter);
router.use('/user', UserRouter);
router.use('/course', CourseRouter);


export { router as indexRoute };
