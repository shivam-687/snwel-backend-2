import express from 'express';
import { register, login } from '@/controllers/authController';
import { authenticateJWT } from '@/middleware/auth.middleware';
import passport from '@/config/passport-config';
import { CommonConfig } from '@/config/common';
const jwt = require('jsonwebtoken');

const AuthRouter = express.Router();

// Register route
AuthRouter.post('/register',
    passport.authenticate('signup', { session: false }),
    async (req, res, next) => {
        res.json({
            message: 'Signup successful',
            user: req.user
        });
    });

// Login route
// ...

const router = express.Router();

// ...

router.post(
  '/login',
  async (req, res, next) => {
    passport.authenticate(
      'login',
      async (err: any, user: any, info: any) => {
        try {
          if (err || !user) {
            const error = new Error('An error occurred.');

            return next(error);
          }

          req.login(
            user,
            { session: false },
            async (error) => {
              if (error) return next(error);

              const body = { _id: user._id, email: user.email };
              const token = jwt.sign({ user: body }, CommonConfig.JWT_SECRET);

              return res.json({ token });
            }
          );
        } catch (error) {
          return next(error);
        }
      }
    )(req, res, next);
  }
);

module.exports = router;

export default AuthRouter;
