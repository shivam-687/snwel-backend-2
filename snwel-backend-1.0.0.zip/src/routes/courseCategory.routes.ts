import express from 'express';
import { getAllCategories, createCategory, getCategoryById, updateCategoryById, deleteCategoryById } from '../controllers/courseCategoryController';


const router = express.Router();

// GET all course categories
router.get('/', getAllCategories);

// GET course category by ID
router.get('/:id', getCategoryById);

// POST create course category
router.post('/', createCategory);

// PUT update course category by ID
router.put('/:id', updateCategoryById);

// DELETE delete course category by ID
router.delete('/:id', deleteCategoryById);

export  {router as CourseCategoryRouter};
