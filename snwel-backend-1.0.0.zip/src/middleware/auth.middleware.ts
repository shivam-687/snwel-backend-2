
import passport from '@/config/passport-config';
import { Request, Response, NextFunction } from 'express';

export const authenticateJWT = (req: Request, res: Response, next: NextFunction) => {
    passport.authenticate('jwt', { session: false }, (error: any, user: Express.User | undefined, info: any) => {
        if (error) {
            return res.status(500).json({ message: 'Internal server error' });
        }
        if (!user) {
            return res.status(401).json({ message: 'Unauthorized' });
        }
        // If authentication is successful, attach the user object to the request
        req.user = user;
        next();
    })(req, res, next);
};
