import { CourseCategoryModel, CourseCategory } from '@/models/CourseCategory';

// Function to create a new course category
const createCourseCategory = async (categoryData: CourseCategory): Promise<CourseCategory> => {
    try {
        const newCategory = new CourseCategoryModel(categoryData);
        return await newCategory.save();
    } catch (error: any) {
        throw new Error(`Error creating course category: ${error.message}`);
    }
};

// Function to retrieve all course categories
const getAllCourseCategories = async (): Promise<CourseCategory[]> => {
    try {
        return await CourseCategoryModel.find().exec();
    } catch (error: any) {
        throw new Error(`Error retrieving course categories: ${error.message}`);
    }
};

// Function to retrieve a course category by ID
const getCourseCategoryById = async (categoryId: string): Promise<CourseCategory | null> => {
    try {
        return await CourseCategoryModel.findById(categoryId).exec();
    } catch (error: any) {
        throw new Error(`Error retrieving course category: ${error.message}`);
    }
};

// Function to update a course category by ID
const updateCourseCategoryById = async (categoryId: string, updateData: Partial<CourseCategory>): Promise<CourseCategory | null> => {
    try {
        return await CourseCategoryModel.findByIdAndUpdate(categoryId, updateData, { new: true }).exec();
    } catch (error: any) {
        throw new Error(`Error updating course category: ${error.message}`);
    }
};

// Function to delete a course category by ID
const deleteCourseCategoryById = async (categoryId: string): Promise<void> => {
    try {
        await CourseCategoryModel.findByIdAndDelete(categoryId).exec();
    } catch (error: any) {
        throw new Error(`Error deleting course category: ${error.message}`);
    }
};

export { createCourseCategory, getAllCourseCategories, getCourseCategoryById, updateCourseCategoryById, deleteCourseCategoryById };
