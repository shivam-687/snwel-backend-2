import { CourseModel, Course } from '@/models/CourseModel';

// Function to create a new course
const createCourse = async (courseData: Course): Promise<Course> => {
    try {
        const newCourse = new CourseModel(courseData);
        return await newCourse.save();
    } catch (error: any) {
        throw new Error(`Error creating course: ${error.message}`);
    }
};

// Function to retrieve all courses
const getAllCourses = async (): Promise<Course[]> => {
    try {
        return await CourseModel.find().exec();
    } catch (error: any) {
        throw new Error(`Error retrieving courses: ${error.message}`);
    }
};

// Function to retrieve a course by ID
const getCourseById = async (courseId: string): Promise<Course | null> => {
    try {
        return await CourseModel.findById(courseId).exec();
    } catch (error: any) {
        throw new Error(`Error retrieving course: ${error.message}`);
    }
};

// Function to update a course by ID
const updateCourseById = async (courseId: string, updateData: Partial<Course>): Promise<Course | null> => {
    try {
        return await CourseModel.findByIdAndUpdate(courseId, updateData, { new: true }).exec();
    } catch (error: any) {
        throw new Error(`Error updating course: ${error.message}`);
    }
};

// Function to delete a course by ID
const deleteCourseById = async (courseId: string): Promise<void> => {
    try {
        await CourseModel.findByIdAndDelete(courseId).exec();
    } catch (error: any) {
        throw new Error(`Error deleting course: ${error.message}`);
    }
};

export { createCourse, getAllCourses, getCourseById, updateCourseById, deleteCourseById };
