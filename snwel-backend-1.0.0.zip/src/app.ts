import express from 'express';
import { indexRoute } from './routes/indexRoutes';
import { loggerMiddleware } from './middleware/loggerMiddleware';
import securityMiddleware from './middleware/security.middleware';
import GlobalState from './utils/globalState';
import connectDB from './utils/db';
import passport from './config/passport-config';


const app = express();

connectDB();
app.use(passport.initialize());
app.use(express.json());
app.use(securityMiddleware);
app.use(loggerMiddleware);
app.use('/', indexRoute)



export { app };
