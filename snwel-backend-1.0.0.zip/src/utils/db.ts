import { CommonConfig } from '@/config/common';
import mongoose from 'mongoose';

const connectDB = async () => {
    try {
        console.log("Mongoose connecting...", CommonConfig.DATABASE_URL)
        const connection = await mongoose.connect('mongodb://127.0.0.1:27017/snwel', {});
        
        console.log(`MongoDB connected: ${connection.connection.host}`);
    } catch (error: any) {
        console.error(`Error connecting to MongoDB: ${error.message}`);
        process.exit(1); // Exit process with failure
    }
};

export default connectDB;
