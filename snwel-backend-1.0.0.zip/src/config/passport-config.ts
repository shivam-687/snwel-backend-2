import passport from 'passport';
import { Strategy as JwtStrategy, ExtractJwt } from 'passport-jwt';
const localStrategy = require('passport-local').Strategy;
import { UserModel } from '@/models/User'; // Assuming you have your User model in a file named user.model.ts
import { CommonConfig } from './common';

const jwtOptions = {
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
  secretOrKey: CommonConfig.JWT_SECRET, // Replace with your actual secret key
  session: false
};

passport.use(
  'signup',
  new localStrategy({
    usernameField: 'email',
    passwordField: 'password'
  },
    async (email: string, password: string, done: any) => {
      try {
        const user = await UserModel.create({ email, password });
        return done(null, user);
      } catch (error) {
        done(error);
      }
    })
);

// ...

passport.use(
  'login',
  new localStrategy(
    {
      usernameField: 'email',
      passwordField: 'password'
    },
    async (email: string, password: string, done: any) => {
      try {
        const user = await UserModel.findOne({ email });

        if (!user) {
          return done(null, false, { message: 'User not found' });
        }

        const validate = await user.isValidPassword(password);

        if (!validate) {
          return done(null, false, { message: 'Wrong Password' });
        }

        return done(null, user, { message: 'Logged in Successfully' });
      } catch (error) {
        return done(error);
      }
    }
  )
);

passport.use(new JwtStrategy(jwtOptions, async (jwtPayload, done) => {
  // console.log("jwtPayload", jwtPayload)
  try {
    const user = await UserModel.findOne({_id: jwtPayload.user._id});
    if (user) {
      return done(null, user);
    } else {
      return done(null, false);
    }
  } catch (error) {
    return done(error, false);
  }
}));

export default passport;
