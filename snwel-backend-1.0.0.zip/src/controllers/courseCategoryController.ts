import { Request, Response } from 'express';
import { getAllCourseCategories, createCourseCategory, getCourseCategoryById, updateCourseCategoryById, deleteCourseCategoryById } from '@/service/courseCategoryService';

// Controller function to get all course categories
const getAllCategories = async (req: Request, res: Response): Promise<void> => {
    try {
        const courseCategories = await getAllCourseCategories();
        res.status(200).json(courseCategories);
    } catch (error: any) {
        res.status(500).json({ message: error.message });
    }
};

// Controller function to create a course category
const createCategory = async (req: Request, res: Response): Promise<void> => {
    try {
        const newCategory = await createCourseCategory(req.body);
        res.status(201).json(newCategory);
    } catch (error: any) {
        res.status(400).json({ message: error.message });
    }
};

// Controller function to get a course category by ID
const getCategoryById = async (req: Request, res: Response): Promise<void> => {
    try {
        const categoryId = req.params.id;
        const category = await getCourseCategoryById(categoryId);
        if (!category) {
            res.status(404).json({ message: 'Course category not found' });
            return;
        }
        res.status(200).json(category);
    } catch (error: any) {
        res.status(500).json({ message: error.message });
    }
};

// Controller function to update a course category by ID
const updateCategoryById = async (req: Request, res: Response): Promise<void> => {
    try {
        const categoryId = req.params.id;
        const updatedCategory = await updateCourseCategoryById(categoryId, req.body);
        if (!updatedCategory) {
            res.status(404).json({ message: 'Course category not found' });
            return;
        }
        res.status(200).json(updatedCategory);
    } catch (error: any) {
        res.status(400).json({ message: error.message });
    }
};

// Controller function to delete a course category by ID
const deleteCategoryById = async (req: Request, res: Response): Promise<void> => {
    try {
        const categoryId = req.params.id;
        await deleteCourseCategoryById(categoryId);
        res.status(204).send();
    } catch (error: any) {
        res.status(500).json({ message: error.message });
    }
};

export { getAllCategories, createCategory, getCategoryById, updateCategoryById, deleteCategoryById };
