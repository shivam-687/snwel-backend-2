import { UserModel } from "@/models/User";
import { Request, Response } from "express";

export const getUserListController = async (req: Request, res: Response) => {
    console.log({user: req.user})
    const user = await UserModel.find({});
    return res.json({data: user})
}