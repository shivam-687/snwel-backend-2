import { Request, Response } from 'express';
import {createCourse, getAllCourses} from '@/service/courseService'
import { CourseCategoryModel, CourseCategory } from '@/models/CourseCategory';
import { courseErrorResponse, errorResponse, successResponse } from '@/utils/helpers/appResponse';
import { Course } from '@/models/CourseModel';

// Function to get all courses
const getAllCoursesController = async (req: Request, res: Response): Promise<void> => {
    try {
        const courses = await getAllCourses();
        return successResponse(courses, res, {message: "Course Fetched successfully!"})
    } catch (error: any) {
        res.status(500).json({ message: `Error getting courses: ${error.message}` });
    }
};

// Function to create a new course
const createCourseController = async (req: Request, res: Response): Promise<void> => {
    try {
        const courseData: Course = req.body;
        const newCourse = await createCourse(courseData);
        res.status(201).json(newCourse);
    } catch (error: any) {
        res.status(500).json({ message: `Error creating course: ${error.message}` });
    }
};

// Function to get course by id
const getCourseByIdController = async (req: Request, res: Response): Promise<void> => {
    try {
        const {courseId} = req.params;
        if(!courseId){
            return courseErrorResponse.notFound(null, res)
        }
        const categories = await CourseCategoryModel.find().exec();
        res.status(200).json(categories);
    } catch (error: any) {
        res.status(500).json({ message: `Error getting course categories: ${error.message}` });
    }
};


// Function to get all course categories
const getAllCourseCategoriesController = async (req: Request, res: Response): Promise<void> => {
    try {
        const categories = await CourseCategoryModel.find().exec();
        res.status(200).json(categories);
    } catch (error: any) {
        res.status(500).json({ message: `Error getting course categories: ${error.message}` });
    }
};

// Function to create a new course category
const createCourseCategoryController = async (req: Request, res: Response): Promise<void> => {
    try {
        const categoryData: CourseCategory = req.body;
        const newCategory = await CourseCategoryModel.create(categoryData);
        res.status(201).json(newCategory);
    } catch (error: any) {
        res.status(500).json({ message: `Error creating course category: ${error.message}` });
    }
};

export { 
    getAllCoursesController, 
    createCourseController, 
    getAllCourseCategoriesController, 
    createCourseCategoryController,
    getCourseByIdController
};
