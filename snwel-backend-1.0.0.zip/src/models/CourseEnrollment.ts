import mongoose, { Document, Schema, Types } from 'mongoose';


interface CourseEnrollment extends Document {
    userId: Types.ObjectId; // Reference to the user who requested the enrollment
    courseId: Types.ObjectId; // Reference to the course for which enrollment is requested
    status: 'ACTIVE' | 'PENDING' | 'DECLINED'; // Enrollment status
    paymentStatus: boolean; // Payment status
    paymentMethod: string; // Payment method
    expiredAt: Date; // Expiration date
    createdAt: Date; // Timestamp provided by Mongoose
    updatedAt: Date; // Timestamp provided by Mongoose
}

const CourseEnrollmentSchema = new Schema<CourseEnrollment>({
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true },
    status: { type: String, enum: ['ACTIVE', 'PENDING', 'DECLINED'], required: true },
    paymentStatus: { type: Boolean, default: false },
    paymentMethod: { type: String },
    expiredAt: { type: Date, required: true },
}, { timestamps: true }); // This option enables Mongoose to add createdAt and updatedAt timestamps automatically

const CourseEnrollmentModel = mongoose.model<CourseEnrollment>('CourseEnrollment', CourseEnrollmentSchema);

export default CourseEnrollmentModel;

