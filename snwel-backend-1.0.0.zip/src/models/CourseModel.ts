import mongoose, {Document, Schema, Types} from 'mongoose';


export interface Course extends Document {
    id: string;
    image?: string;
    title: string;
    shortDescription: string;
    text: string;
    courseDuration: string;
    categories: Types.ObjectId[];
    instructors: Types.ObjectId[];
    difficulty: string;
    language: string[];
    assessment: string;
    certificate: boolean;
    lessons: number;
    rating: number;
    enrolled: number;
    isPopular: boolean;
    price: number;
    currency: string;
    discount?: number;
    isPremium?: boolean;
    masterCategory: string;
    appearence?: {
        themeColor?: string;
        forgroundColor?: string;
    };
    images?: {
        promotionalCardImage?: string;
        iconImage?: string;
    };
    curriculum: { title: string; duration: string }[];
}



const CourseSchema = new Schema<Course>({
    id: String,
    image: String,
    title: String,
    shortDescription: String,
    text: String,
    courseDuration: String,
    categories: [{ type: Types.ObjectId, ref: 'CourseCategory' }],
    instructors: [{ type: Types.ObjectId, ref: 'User' }],
    difficulty: String,
    language: [String],
    assessment: String,
    certificate: Boolean,
    lessons: Number,
    rating: Number,
    enrolled: Number,
    isPopular: Boolean,
    price: Number,
    currency: String,
    discount: Number,
    isPremium: Boolean,
    masterCategory: String,
    appearence: {
        themeColor: String,
        forgroundColor: String,
    },
    images: {
        promotionalCardImage: String,
        iconImage: String,
    },
    curriculum: [{ title: String, duration: String }],
}, {timestamps: true});


export const CourseModel = mongoose.model<Course>('Course', CourseSchema);