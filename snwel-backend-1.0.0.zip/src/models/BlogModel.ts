import mongoose, {Document, Schema} from 'mongoose'

interface Blog extends Document {
    id: string;
    slug: string;
    title: string;
    description: string;
    shortDescription: string;
    category: string;
    thumbnail: string;
    authorId: string; // Assuming authorId is of type string
}

const BlogSchema = new Schema<Blog>({
    id: String,
    slug: String,
    title: String,
    description: String,
    shortDescription: String,
    category: String,
    thumbnail: String,
    authorId: String,
});

export const BlogModel = mongoose.model<Blog>('Blog', BlogSchema);