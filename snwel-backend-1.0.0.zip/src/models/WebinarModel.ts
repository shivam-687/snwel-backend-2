import mongoose, {Document, Schema} from 'mongoose';

interface Webinar extends Document {
    id: string;
    title: string;
    shortDescription: string;
    content: string;
    startDate: string;
    slug: string;
    thumbnail: string;
}


const WebinarSchema = new Schema<Webinar>({
    id: String,
    title: String,
    shortDescription: String,
    content: String,
    startDate: String,
    slug: String,
    thumbnail: String,
});

export const WebinarModel = mongoose.model<Webinar>('Webinar', WebinarSchema);