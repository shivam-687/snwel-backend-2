import mongoose, {Document, Schema} from 'mongoose'


export interface CourseCategory extends Document {
    id: string;
    title: string;
    description?: string;
    shortDescription?: string;
    isPremium?: boolean;
    parentCategory?: CourseCategory;
}

const CourseCategorySchema = new Schema<CourseCategory>({
    id: String,
    title: String,
    description: String,
    shortDescription: String,
    isPremium: Boolean,
    parentCategory: { type: Schema.Types.ObjectId, ref: 'CourseCategory' }, // Assuming CourseCategory has a self-referencing relationship
});

export const CourseCategoryModel = mongoose.model<CourseCategory>('CourseCategory', CourseCategorySchema);