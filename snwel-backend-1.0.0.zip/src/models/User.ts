import mongoose, { Document, Schema, Types } from 'mongoose';
import bcrypt from 'bcrypt';

// Define interfaces for TypeScript type checking
interface User extends Document {
    username: string;
    email: string;
    password: string;
    roles: string[]; // Assuming roles are stored as an array of strings
    courses: Types.ObjectId[]; // Assuming courses are referenced by their IDs
    webinars: Types.ObjectId[]; // Assuming webinars are referenced by their IDs
    appliedJobs: Types.ObjectId[]; // Assuming applied jobs are referenced by their IDs
    isValidPassword: (password: string) => Promise<boolean>
}


const UserSchema = new Schema<User>({
    username: String,
    email: String,
    password: String,
    roles: [String],
    courses: [{ type: Schema.Types.ObjectId, ref: 'Course' }], // Reference to Course model
    webinars: [{ type: Schema.Types.ObjectId, ref: 'Webinar' }], // Reference to Webinar model
    appliedJobs: [{ type: Schema.Types.ObjectId, ref: 'Job' }], // Reference to Job model
});

UserSchema.pre(
    'save',
    async function(next) {
      const user = this;
      const hash = await bcrypt.hash(this.password, 10);
      this.password = hash;
      next();
    }
  );

  UserSchema.methods.isValidPassword = async function(password: string) {
    const user = this;
    const compare = await bcrypt.compare(password, user.password);
  
    return compare;
  }



export const UserModel = mongoose.model<User>('User', UserSchema);