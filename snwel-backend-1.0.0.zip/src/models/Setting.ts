import mongoose, {Document, Schema} from 'mongoose'

interface Setting extends Document {
    id: string;
    code: string;
    data: string;
    isChangable: boolean;
}


const SettingSchema = new Schema<Setting>({
    id: String,
    code: String,
    data: String,
    isChangable: Boolean,
});


export const SettingModel = mongoose.model<Setting>('Setting', SettingSchema);