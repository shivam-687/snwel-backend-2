import { User as UserModel } from './models/user.model'; // Import your custom User model

declare global {
    namespace Express {
        interface User extends UserModel {} // Override Express.User with your custom User model
    }
}
